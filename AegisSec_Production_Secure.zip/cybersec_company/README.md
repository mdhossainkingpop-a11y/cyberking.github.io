# AegisSec — Complete Django Cybersecurity Company Platform

Merged Version 1 responsive frontend with Django backend, PostgreSQL support, authentication, client dashboard, admin panel, service requests, email notifications and Docker/Nginx deployment configuration.

## Main routes
- `/` Home
- `/services/` Services
- `/about/` About
- `/security-policy/` Security Policy
- `/request-service/` Assessment request
- `/register/` Account registration
- `/login/` Login
- `/dashboard/` Client dashboard
- `/admin/` Django administration

## Security boundary
The platform is intended for authorized cybersecurity work only. The request form requires authorization confirmation. Do not use the platform to solicit or perform unauthorized access, credential theft, malware deployment, destructive attacks, or attacks on third-party systems without permission.

## Local run
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python manage.py migrate
python manage.py createsuperuser
python seed_services.py
python manage.py runserver
```

## Docker
```bash
cp .env.example .env
# edit .env

docker compose up -d --build
docker compose exec web python manage.py createsuperuser
```

Configure SMTP before production so assessment notifications are delivered by email.
