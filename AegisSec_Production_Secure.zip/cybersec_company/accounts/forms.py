# Public registration is disabled. Kept only to avoid import errors from older deployments.
