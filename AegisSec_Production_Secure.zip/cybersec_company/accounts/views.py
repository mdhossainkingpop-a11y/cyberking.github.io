from django.shortcuts import redirect, render

def register(request):
    # Registration is intentionally disabled. Accounts are provisioned by an administrator
    # or created through an approved Google sign-in flow.
    return redirect('login')
