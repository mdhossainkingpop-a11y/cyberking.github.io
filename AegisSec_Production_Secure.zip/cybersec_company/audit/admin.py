from django.contrib import admin
from .models import AuditEvent
@admin.register(AuditEvent)
class AuditEventAdmin(admin.ModelAdmin):
    list_display = ('created_at','actor','action','method','path','ip_address')
    list_filter = ('action','method','created_at')
    search_fields = ('actor__email','actor__username','path','ip_address','user_agent')
    readonly_fields = [f.name for f in AuditEvent._meta.fields]
