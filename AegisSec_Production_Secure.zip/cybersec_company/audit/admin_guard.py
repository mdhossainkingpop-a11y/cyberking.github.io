from django.conf import settings
from django.http import HttpResponseForbidden
class AdminIPAllowlistMiddleware:
    def __init__(self,get_response): self.get_response=get_response
    def __call__(self,request):
        if request.path.startswith('/admin/') and settings.ADMIN_ALLOWED_IPS:
            ip=request.META.get('REMOTE_ADDR')
            if ip not in settings.ADMIN_ALLOWED_IPS:
                return HttpResponseForbidden('Admin access is restricted.')
        return self.get_response(request)
