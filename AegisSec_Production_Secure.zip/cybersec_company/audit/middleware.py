from .models import AuditEvent

class AuditMiddleware:
    AUDIT_PATHS = ('/login/', '/accounts/', '/request-service/', '/dashboard/', '/admin/')
    def __init__(self, get_response): self.get_response = get_response
    def __call__(self, request):
        response = self.get_response(request)
        if request.method in ('POST','PUT','PATCH','DELETE') or request.path.startswith(self.AUDIT_PATHS):
            try:
                AuditEvent.objects.create(
                    actor=request.user if getattr(request.user, 'is_authenticated', False) else None,
                    action=f'{request.method} {request.path[:70]}', path=request.path[:500], method=request.method,
                    ip_address=self._ip(request), user_agent=request.META.get('HTTP_USER_AGENT','')[:1000],
                    metadata={'status_code': response.status_code}
                )
            except Exception:
                pass
        return response
    def _ip(self, request):
        # Trust only the direct peer; Nginx passes the real client IP via REMOTE_ADDR.
        return request.META.get('REMOTE_ADDR')
