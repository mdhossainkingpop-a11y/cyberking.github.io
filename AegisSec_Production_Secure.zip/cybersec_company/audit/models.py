from django.conf import settings
from django.db import models

class AuditEvent(models.Model):
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)
    actor = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name='audit_events')
    action = models.CharField(max_length=80)
    path = models.CharField(max_length=500, blank=True)
    method = models.CharField(max_length=10, blank=True)
    ip_address = models.GenericIPAddressField(null=True, blank=True)
    user_agent = models.TextField(blank=True)
    metadata = models.JSONField(default=dict, blank=True)
    class Meta:
        ordering = ['-created_at']
    def __str__(self):
        who = self.actor.email if self.actor else 'anonymous'
        return f'{self.created_at:%Y-%m-%d %H:%M} {who} {self.action}'
