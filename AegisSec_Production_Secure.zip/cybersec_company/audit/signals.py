from django.contrib.auth.signals import user_logged_in, user_login_failed, user_logged_out
from django.dispatch import receiver
from .models import AuditEvent

def ip(request): return request.META.get('REMOTE_ADDR') if request else None
@receiver(user_logged_in)
def logged_in(sender, request, user, **kwargs):
    AuditEvent.objects.create(actor=user, action='login_success', path=request.path, method=request.method, ip_address=ip(request), user_agent=request.META.get('HTTP_USER_AGENT','')[:1000])
@receiver(user_logged_out)
def logged_out(sender, request, user, **kwargs):
    AuditEvent.objects.create(actor=user, action='logout', path=request.path, method=request.method, ip_address=ip(request), user_agent=request.META.get('HTTP_USER_AGENT','')[:1000])
@receiver(user_login_failed)
def login_failed(sender, credentials, request, **kwargs):
    AuditEvent.objects.create(action='login_failed', path=request.path if request else '', method=request.method if request else '', ip_address=ip(request), user_agent=request.META.get('HTTP_USER_AGENT','')[:1000] if request else '', metadata={'identifier':'email' if 'email' in credentials else 'unknown'})
