import os
from pathlib import Path
BASE_DIR = Path(__file__).resolve().parent.parent
SECRET_KEY = os.environ.get('DJANGO_SECRET_KEY', 'unsafe-dev-key-change-me')
DEBUG = os.environ.get('DJANGO_DEBUG','0') == '1'
ALLOWED_HOSTS = [x.strip() for x in os.environ.get('DJANGO_ALLOWED_HOSTS','localhost,127.0.0.1').split(',') if x.strip()]
CSRF_TRUSTED_ORIGINS = [x.strip() for x in os.environ.get('DJANGO_CSRF_TRUSTED_ORIGINS','').split(',') if x.strip()]
INSTALLED_APPS=[
 'django.contrib.admin','django.contrib.auth','django.contrib.contenttypes','django.contrib.sessions','django.contrib.messages','django.contrib.staticfiles',
 'allauth','allauth.account','allauth.socialaccount','allauth.socialaccount.providers.google','services','accounts','audit'
]
MIDDLEWARE=['django.middleware.security.SecurityMiddleware','whitenoise.middleware.WhiteNoiseMiddleware','django.contrib.sessions.middleware.SessionMiddleware','django.middleware.common.CommonMiddleware','django.middleware.csrf.CsrfViewMiddleware','django.contrib.auth.middleware.AuthenticationMiddleware','django.contrib.messages.middleware.MessageMiddleware','django.middleware.clickjacking.XFrameOptionsMiddleware','audit.admin_guard.AdminIPAllowlistMiddleware','audit.middleware.AuditMiddleware']
ROOT_URLCONF='core.urls'
TEMPLATES=[{'BACKEND':'django.template.backends.django.DjangoTemplates','DIRS':[BASE_DIR/'templates'],'APP_DIRS':True,'OPTIONS':{'context_processors':['django.template.context_processors.request','django.contrib.auth.context_processors.auth','django.contrib.messages.context_processors.messages','allauth.account.context_processors.account']}}]
WSGI_APPLICATION='core.wsgi.application'
if os.environ.get('POSTGRES_DB'):
 DATABASES={'default':{'ENGINE':'django.db.backends.postgresql','NAME':os.environ['POSTGRES_DB'],'USER':os.environ.get('POSTGRES_USER','cybersec'),'PASSWORD':os.environ.get('POSTGRES_PASSWORD',''),'HOST':os.environ.get('POSTGRES_HOST','db'),'PORT':os.environ.get('POSTGRES_PORT','5432'),'CONN_MAX_AGE':60}}
else: DATABASES={'default':{'ENGINE':'django.db.backends.sqlite3','NAME':BASE_DIR/'db.sqlite3'}}
AUTH_PASSWORD_VALIDATORS=[{'NAME':'django.contrib.auth.password_validation.UserAttributeSimilarityValidator'},{'NAME':'django.contrib.auth.password_validation.MinimumLengthValidator','OPTIONS':{'min_length':12}},{'NAME':'django.contrib.auth.password_validation.CommonPasswordValidator'},{'NAME':'django.contrib.auth.password_validation.NumericPasswordValidator'}]
LANGUAGE_CODE='en-us'; TIME_ZONE='Asia/Dhaka'; USE_I18N=True; USE_TZ=True
STATIC_URL='/static/'; STATIC_ROOT=BASE_DIR/'staticfiles'; STATICFILES_DIRS=[BASE_DIR/'static']
MEDIA_URL='/media/'; MEDIA_ROOT=BASE_DIR/'media'
DEFAULT_AUTO_FIELD='django.db.models.BigAutoField'
LOGIN_URL='/accounts/login/'; LOGIN_REDIRECT_URL='/dashboard/'; LOGOUT_REDIRECT_URL='/'
AUTHENTICATION_BACKENDS=['django.contrib.auth.backends.ModelBackend','allauth.account.auth_backends.AuthenticationBackend']
# Email/password login only; public signup is disabled. Local accounts should be provisioned by admin.
ACCOUNT_LOGIN_METHODS={'email'}
ACCOUNT_SIGNUP_ENABLED=False
ACCOUNT_EMAIL_VERIFICATION='none'
ACCOUNT_LOGIN_ON_PASSWORD_RESET=True
ACCOUNT_RATE_LIMITS={'login':'5/m/ip','login_failed':'5/5m/key,10/m/ip','reset_password':'5/m/ip,3/m/key','reset_password_from_key':'5/m/ip'}
SOCIALACCOUNT_LOGIN_ON_GET=False
SOCIALACCOUNT_AUTO_SIGNUP=True
SOCIALACCOUNT_QUERY_EMAIL=True
SOCIALACCOUNT_PROVIDERS={'google':{'APP':{'client_id':os.environ.get('GOOGLE_CLIENT_ID',''),'secret':os.environ.get('GOOGLE_CLIENT_SECRET',''),'key':''},'SCOPE':['profile','email'],'AUTH_PARAMS':{'access_type':'online'}}}
EMAIL_BACKEND=os.environ.get('EMAIL_BACKEND','django.core.mail.backends.console.EmailBackend')
EMAIL_HOST=os.environ.get('EMAIL_HOST',''); EMAIL_PORT=int(os.environ.get('EMAIL_PORT','587')); EMAIL_HOST_USER=os.environ.get('EMAIL_HOST_USER',''); EMAIL_HOST_PASSWORD=os.environ.get('EMAIL_HOST_PASSWORD',''); EMAIL_USE_TLS=os.environ.get('EMAIL_USE_TLS','1')=='1'; EMAIL_USE_SSL=os.environ.get('EMAIL_USE_SSL','0')=='1'
DEFAULT_FROM_EMAIL=os.environ.get('DEFAULT_FROM_EMAIL','webmaster@localhost'); SECURITY_CONTACT_EMAIL=os.environ.get('SECURITY_CONTACT_EMAIL',DEFAULT_FROM_EMAIL)
SECURE_PROXY_SSL_HEADER=('HTTP_X_FORWARDED_PROTO','https') if not DEBUG else None
if not DEBUG:
 SECURE_SSL_REDIRECT=True; SESSION_COOKIE_SECURE=True; CSRF_COOKIE_SECURE=True; SESSION_COOKIE_HTTPONLY=True; SESSION_COOKIE_SAMESITE='Lax'; CSRF_COOKIE_SAMESITE='Lax'; SECURE_HSTS_SECONDS=31536000; SECURE_HSTS_INCLUDE_SUBDOMAINS=True; SECURE_HSTS_PRELOAD=True; SECURE_CONTENT_TYPE_NOSNIFF=True; X_FRAME_OPTIONS='DENY'; SECURE_REFERRER_POLICY='same-origin'; SECURE_CROSS_ORIGIN_OPENER_POLICY='same-origin'; SECURE_BROWSER_XSS_FILTER=False
# Optional admin IP allowlist. Leave empty to permit admin from any IP, while still requiring staff/superuser auth.
ADMIN_ALLOWED_IPS={x.strip() for x in os.environ.get('ADMIN_ALLOWED_IPS','').split(',') if x.strip()}
