from django.contrib import admin
from django.urls import path, include
from django.contrib.auth import views as auth_views
from services import views
from allauth.account.decorators import secure_admin_login

admin.autodiscover()
admin.site.login = secure_admin_login(admin.site.login)
admin.site.site_header = 'AegisSec Security Administration'
admin.site.site_title = 'AegisSec Admin'
admin.site.index_title = 'Security Operations'

urlpatterns = [
    path('admin/', admin.site.urls),
    path('accounts/', include('allauth.urls')),
    path('', views.home, name='home'),
    path('services/', views.service_list, name='services'),
    path('request-service/', views.request_service, name='request_service'),
    path('thank-you/', views.thank_you, name='thank_you'),
    path('about/', views.about, name='about'),
    path('security-policy/', views.security_policy, name='security_policy'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('dashboard/request/<int:pk>/', views.request_detail, name='request_detail'),
]
