# AegisSec production deployment

## 1. DNS
Point the domain A/AAAA records to the server. Ensure ports 80 and 443 are open.

## 2. Environment
Copy `.env.example` to `.env`, set a strong random `DJANGO_SECRET_KEY`, PostgreSQL password, domain, SMTP credentials, and Google OAuth credentials. Never commit `.env`.

## 3. Google OAuth
In Google Cloud Console create an OAuth 2.0 Web application. Add this production callback:
`https://YOUR-DOMAIN/accounts/google/login/callback/`
Set the authorized JavaScript origin to `https://YOUR-DOMAIN`. Put the client ID and secret in `.env`.

## 4. First certificate
Create the ACME webroot directories and obtain the certificate with `deploy/init_cert.sh`. If your Nginx config cannot start before certificates exist, use a temporary HTTP-only server block for the first ACME request, then restore `nginx/default.conf` and restart Nginx.

## 5. Build and migrate
`docker compose up -d --build`
`docker compose exec web python manage.py migrate`
`docker compose exec web python manage.py collectstatic --noinput`
`docker compose exec web python manage.py createsuperuser --username admin --email admin@YOUR-DOMAIN`
`docker compose exec web python manage.py check --deploy`

## 6. Admin security
Optionally set `ADMIN_ALLOWED_IPS` to trusted fixed public IP addresses. Do not expose the admin unnecessarily. Use a strong admin password and keep the admin account separate from client accounts.

## 7. Automated PostgreSQL backups
Test a backup first:
`./deploy/backup_postgres.sh`
Then schedule it with cron, for example daily at 02:30:
`30 2 * * * /opt/aegissec/deploy/backup_postgres.sh >> /var/log/aegissec-backup.log 2>&1`
Store copies off-server as well; a backup on the same disk is not a disaster-recovery plan.

## 8. Certificate renewal
Schedule `deploy/renew_cert.sh` twice daily or use your host's certificate automation. Test renewal before relying on it.

## 9. Login behavior
There is no public registration UI. Client login supports email + password and Google. Email/password client accounts are provisioned by an administrator. Google sign-in may create a client account automatically because that is part of the OAuth sign-in flow.

## 10. Production notes
Django recommends HTTPS for sites with login, secure cookies, HSTS, a production WSGI/ASGI server, `DEBUG=False`, protected secrets, and database backups. Review `python manage.py check --deploy` before launch.
