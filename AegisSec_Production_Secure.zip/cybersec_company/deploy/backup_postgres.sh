#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
source .env
BACKUP_DIR="${BACKUP_DIR:-./backups}"
RETENTION_DAYS="${RETENTION_DAYS:-14}"
mkdir -p "$BACKUP_DIR"
STAMP=$(date -u +%Y%m%dT%H%M%SZ)
FILE="$BACKUP_DIR/${POSTGRES_DB}_${STAMP}.dump.gz"
docker compose exec -T db pg_dump -U "$POSTGRES_USER" -d "$POSTGRES_DB" --format=custom | gzip > "$FILE"
find "$BACKUP_DIR" -type f -name '*.dump.gz' -mtime +"$RETENTION_DAYS" -delete
printf 'Backup created: %s\n' "$FILE"
