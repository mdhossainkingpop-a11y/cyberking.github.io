#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
source .env
if [ -z "${DOMAIN:-}" ]; then echo 'Set DOMAIN in .env'; exit 1; fi
# Start HTTP endpoint first so ACME HTTP-01 can validate the domain.
docker compose up -d nginx web db
# For the first certificate, temporarily use an HTTP-only nginx config if needed; then install the cert and restore the HTTPS config.
docker run --rm -v "$PWD/certbot/www:/var/www/certbot" -v "$PWD/certbot/conf:/etc/letsencrypt" certbot/certbot certonly --webroot -w /var/www/certbot -d "$DOMAIN" --email "${SECURITY_CONTACT_EMAIL}" --agree-tos --no-eff-email
printf 'Certificate obtained. Restarting Nginx.\n'
docker compose restart nginx
