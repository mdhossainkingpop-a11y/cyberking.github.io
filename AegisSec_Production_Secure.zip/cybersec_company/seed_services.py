import os
os.environ.setdefault('DJANGO_SETTINGS_MODULE','core.settings')
import django
django.setup()
from services.models import Service
items=[
('Web Application Penetration Testing','web-app-pentest','Identify exploitable weaknesses in authorized web applications.','Controlled testing for authentication, authorization, input validation, session security, business logic and common OWASP risks.'),
('API Security Testing','api-security','Assess REST/GraphQL APIs for security weaknesses.','Evaluate authentication, authorization, object-level access controls, validation, rate limits and sensitive data exposure.'),
('Mobile Application Security Testing','mobile-security','Assess Android/iOS application security.','Review application behavior, storage, transport security, authentication and API interactions within an agreed scope.'),
('Network Security Assessment','network-security','Evaluate an authorized network environment.','Identify exposed services, configuration weaknesses, segmentation issues and practical attack paths.'),
('Cloud Security Assessment','cloud-security','Review cloud configurations and security controls.','Assess identity, storage, network exposure, logging and configuration risks for approved cloud assets.'),
('Vulnerability Assessment','vulnerability-assessment','Find and prioritize security weaknesses.','Combine controlled discovery with risk-based prioritization and remediation recommendations.'),
('Security Audit & Hardening','security-audit','Improve security posture and configuration.','Review security controls and provide practical hardening recommendations.'),
('Authorized Red Team Assessment','red-team','Simulate realistic attacker behavior within strict rules of engagement.','Controlled adversary simulation against approved assets with safety limits, scope and reporting requirements.'),
]
for i,(n,s,sd,d) in enumerate(items): Service.objects.update_or_create(slug=s,defaults={'name':n,'short_description':sd,'description':d,'order':i,'active':True})
print('Seeded services.')
