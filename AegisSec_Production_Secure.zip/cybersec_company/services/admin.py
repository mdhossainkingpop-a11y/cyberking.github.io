from django.contrib import admin
from .models import Service, ServiceRequest

@admin.register(Service)
class ServiceAdmin(admin.ModelAdmin):
    list_display = ('name','active','order')
    list_filter = ('active',)
    prepopulated_fields = {'slug': ('name',)}
    search_fields = ('name','short_description','description')
    ordering = ('order','name')

@admin.register(ServiceRequest)
class ServiceRequestAdmin(admin.ModelAdmin):
    list_display = ('id','name','email','service','status','authorization_confirmed','created_at')
    list_filter = ('status','authorization_confirmed','service','created_at')
    search_fields = ('name','email','company','target','scope')
    readonly_fields = ('created_at','updated_at')
    list_select_related = ('service','client')
    fieldsets = (
        ('Client', {'fields': ('client','name','email','company','phone')}),
        ('Engagement', {'fields': ('service','target','scope','authorization_confirmed','status')}),
        ('Internal', {'fields': ('notes','created_at','updated_at')}),
    )
