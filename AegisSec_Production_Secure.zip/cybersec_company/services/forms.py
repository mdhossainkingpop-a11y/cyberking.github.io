from django import forms
from .models import ServiceRequest, Service

class ServiceRequestForm(forms.ModelForm):
    class Meta:
        model = ServiceRequest
        fields = ['name','email','company','phone','service','target','scope','authorization_confirmed']
        widgets = {'scope': forms.Textarea(attrs={'rows': 7, 'placeholder': 'Describe the system, authorized scope, objectives and timeline. Do not send passwords or secrets.'})}
    def clean_authorization_confirmed(self):
        value = self.cleaned_data['authorization_confirmed']
        if not value: raise forms.ValidationError('Written authorization is required before testing can begin.')
        return value
    def clean_scope(self):
        value = self.cleaned_data['scope'].strip()
        if len(value) < 20: raise forms.ValidationError('Please provide enough scope information for an initial review.')
        return value
