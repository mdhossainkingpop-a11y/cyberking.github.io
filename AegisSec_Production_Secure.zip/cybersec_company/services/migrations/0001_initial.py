from django.db import migrations, models
import django.db.models.deletion

class Migration(migrations.Migration):
    initial=True
    dependencies=[]
    operations=[
        migrations.CreateModel(name='Service',fields=[
            ('id',models.BigAutoField(auto_created=True,primary_key=True,serialize=False,verbose_name='ID')),
            ('name',models.CharField(max_length=160)),('slug',models.SlugField(unique=True)),
            ('short_description',models.CharField(max_length=280)),('description',models.TextField()),
            ('active',models.BooleanField(default=True)),('order',models.PositiveIntegerField(default=0)),
        ],options={'ordering':['order','name']}),
        migrations.CreateModel(name='ServiceRequest',fields=[
            ('id',models.BigAutoField(auto_created=True,primary_key=True,serialize=False,verbose_name='ID')),
            ('name',models.CharField(max_length=120)),('email',models.EmailField(max_length=254)),('company',models.CharField(blank=True,max_length=160)),
            ('phone',models.CharField(blank=True,max_length=40)),('target',models.CharField(help_text='Domain, app, API, network, etc. Do not submit passwords or secrets.',max_length=255)),
            ('scope',models.TextField(help_text='Describe the authorized scope and objectives.')),('authorization_confirmed',models.BooleanField(default=False)),
            ('status',models.CharField(choices=[('new','New'),('reviewing','Reviewing'),('quoted','Quoted'),('accepted','Accepted'),('closed','Closed'),('rejected','Rejected')],default='new',max_length=20)),
            ('created_at',models.DateTimeField(auto_now_add=True)),('updated_at',models.DateTimeField(auto_now=True)),('notes',models.TextField(blank=True)),
            ('service',models.ForeignKey(on_delete=django.db.models.deletion.PROTECT,related_name='requests',to='services.service')),
        ],options={'ordering':['-created_at']}),
    ]
