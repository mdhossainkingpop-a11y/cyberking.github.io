from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion
class Migration(migrations.Migration):
    dependencies=[('services','0001_initial')]
    operations=[migrations.AddField(model_name='servicerequest',name='client',field=models.ForeignKey(blank=True,null=True,on_delete=django.db.models.deletion.SET_NULL,related_name='service_requests',to=settings.AUTH_USER_MODEL))]
