from django.conf import settings
from django.db import models

class Service(models.Model):
    name = models.CharField(max_length=160)
    slug = models.SlugField(unique=True)
    short_description = models.CharField(max_length=280)
    description = models.TextField()
    active = models.BooleanField(default=True)
    order = models.PositiveIntegerField(default=0)
    def __str__(self): return self.name
    class Meta: ordering = ['order', 'name']

class ServiceRequest(models.Model):
    STATUS = [('new','New'),('reviewing','Reviewing'),('quoted','Quoted'),('accepted','Accepted'),('in_progress','In Progress'),('closed','Closed'),('rejected','Rejected')]
    client = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name='service_requests')
    name = models.CharField(max_length=120)
    email = models.EmailField()
    company = models.CharField(max_length=160, blank=True)
    phone = models.CharField(max_length=40, blank=True)
    service = models.ForeignKey(Service, on_delete=models.PROTECT, related_name='requests')
    target = models.CharField(max_length=255, help_text='Domain, app, API, network, etc. Do not submit passwords or secrets.')
    scope = models.TextField(help_text='Describe the authorized scope and objectives.')
    authorization_confirmed = models.BooleanField(default=False)
    status = models.CharField(max_length=20, choices=STATUS, default='new')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    notes = models.TextField(blank=True)
    def __str__(self): return f'{self.name} — {self.service.name}'
    class Meta: ordering = ['-created_at']
