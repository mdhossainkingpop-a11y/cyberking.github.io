from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.mail import send_mail
from django.shortcuts import get_object_or_404, redirect, render
from django.conf import settings
from .forms import ServiceRequestForm
from .models import Service, ServiceRequest


def home(request):
    return render(request, 'home.html', {'services': Service.objects.filter(active=True)[:6]})

def service_list(request):
    return render(request, 'services.html', {'services': Service.objects.filter(active=True)})

def about(request): return render(request, 'about.html')
def security_policy(request): return render(request, 'security_policy.html')

def request_service(request):
    if request.method == 'POST':
        form = ServiceRequestForm(request.POST)
        if form.is_valid():
            obj = form.save(commit=False)
            if request.user.is_authenticated:
                obj.client = request.user
            obj.save()
            send_mail(
                subject=f'New security assessment request #{obj.pk}',
                message=f'Client: {obj.name}\nEmail: {obj.email}\nService: {obj.service.name}\nTarget: {obj.target}\n\nScope:\n{obj.scope}',
                from_email=settings.DEFAULT_FROM_EMAIL,
                recipient_list=[settings.SECURITY_CONTACT_EMAIL],
                fail_silently=True,
            )
            send_mail(
                subject='AegisSec — Request received',
                message='Thank you. Your authorized security assessment request has been received. Our team will review the scope and contact you.',
                from_email=settings.DEFAULT_FROM_EMAIL,
                recipient_list=[obj.email],
                fail_silently=True,
            )
            messages.success(request, 'Your request has been received. We will contact you after reviewing the scope.')
            return redirect('thank_you')
    else:
        initial = {}
        selected = request.GET.get('service')
        if selected:
            initial['service'] = Service.objects.filter(slug=selected, active=True).first()
        if request.user.is_authenticated:
            initial = {'name': request.user.get_full_name(), 'email': request.user.email}
        form = ServiceRequestForm(initial=initial)
    return render(request, 'contact.html', {'form': form})

def thank_you(request): return render(request, 'services/thank_you.html')

@login_required
def dashboard(request):
    requests = ServiceRequest.objects.filter(client=request.user).select_related('service')
    return render(request, 'dashboard/index.html', {'requests': requests})

@login_required
def request_detail(request, pk):
    obj = get_object_or_404(ServiceRequest, pk=pk, client=request.user)
    return render(request, 'dashboard/detail.html', {'item': obj})
